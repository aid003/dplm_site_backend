module.exports = {
  apps: [
    {
      name: "kosty-lct-frontend",
      script: "npm",
      args: "start",
    },
  ],
};
