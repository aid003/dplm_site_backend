/**
 * API слой приложения
 */

export * from "./patients";
export * from "./studies";
export * from "./websocket";
