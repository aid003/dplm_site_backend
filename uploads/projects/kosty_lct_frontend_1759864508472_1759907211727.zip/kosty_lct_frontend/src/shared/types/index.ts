/**
 * Общие типы приложения
 */

export * from './websocket';

