/**
 * Общие hooks приложения
 */

export * from './use-websocket';
export * from './use-sliding-window';
