/**
 * Слой Entities
 */
