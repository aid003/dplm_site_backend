__turbopack_load_page_chunks__("/_error", [
  "static/chunks/cde7e74d7e9f6d90.js",
  "static/chunks/bb27c4439601ebf7.js",
  "static/chunks/turbopack-8c2de095b3dd3f27.js"
])
