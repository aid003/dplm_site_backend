__turbopack_load_page_chunks__("/_app", [
  "static/chunks/529e8df97c661c4a.js",
  "static/chunks/bb27c4439601ebf7.js",
  "static/chunks/turbopack-4aff3de10bb23427.js"
])
