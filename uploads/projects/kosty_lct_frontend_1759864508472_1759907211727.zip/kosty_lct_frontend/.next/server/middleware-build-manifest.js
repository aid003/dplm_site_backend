globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/529e8df97c661c4a.js",
      "static/chunks/bb27c4439601ebf7.js",
      "static/chunks/turbopack-4aff3de10bb23427.js"
    ],
    "/_error": [
      "static/chunks/cde7e74d7e9f6d90.js",
      "static/chunks/bb27c4439601ebf7.js",
      "static/chunks/turbopack-8c2de095b3dd3f27.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a09cfe2f4fac8644.js",
    "static/chunks/ec2d4fed08d8fe34.js",
    "static/chunks/5f69b76940165eb7.js",
    "static/chunks/b7bde17f339802bb.js",
    "static/chunks/turbopack-aedf69988a57b69f.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];