var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__361b1719._.js")
R.c("server/chunks/ssr/[root-of-the-server]__92b3cbc6._.js")
R.m(99164)
module.exports=R.m(99164).exports
