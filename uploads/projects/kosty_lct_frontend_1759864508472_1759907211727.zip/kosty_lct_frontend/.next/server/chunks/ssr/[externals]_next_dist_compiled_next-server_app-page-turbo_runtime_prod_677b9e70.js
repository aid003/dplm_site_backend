module.exports=[18622,(a,b,c)=>{b.exports=a.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))}];

//# sourceMappingURL=%5Bexternals%5D_next_dist_compiled_next-server_app-page-turbo_runtime_prod_677b9e70.js.map