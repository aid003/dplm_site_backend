module.exports=[7678,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},60594,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(7678).default,width:256,height:256}}];

//# sourceMappingURL=kosty_lct_frontend_src_app_28157e13._.js.map