var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__f1c1796a._.js")
R.c("server/chunks/[root-of-the-server]__2b34eb75._.js")
R.m(43715)
R.m(61613)
module.exports=R.m(61613).exports
